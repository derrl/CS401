import java.io.*;
import queues.*;

public class testFloatingFrontArrayQueue{
	
	
//	FixedFrontArrayBoundedQueue<Employee> QueueList = new FixedFrontArrayBoundedQueue<Employee>();
	FloatingFrontArrayBoundedQueue<Employee> QueueList = new FloatingFrontArrayBoundedQueue<Employee>();
//	ArrayUnboundedQueue<Employee> QueueList = new ArrayUnboundedQueue<Employee>();

	public static void main(String arg[]){
		testFloatingFrontArrayQueue b = new testFloatingFrontArrayQueue();
		b.go();
		for (int i = 0; i < 30;i++)
	    	b.QueueList.dequeue();
	}	

	void go(){
		System.out.println();
		System.out.println("Now we enqueue data:");
		getEmployee();
		System.out.println();
	}
	
	void getEmployee() {
	    try {
	        File file = new File("emp.txt");
	        BufferedReader reader = new BufferedReader(new FileReader(file));
	        String line = null;
	        while((line = reader.readLine()) != null) {
	            addEmployee(line);
	        }
	    }
	    catch (Exception ex) {
	        ex.printStackTrace();
	    }
	}
	
	void addEmployee(String lineToParse) {
	    String[] tokens = lineToParse.split(" ");
	    Employee nextEmployee = new Employee(tokens[0], tokens[1]);
	    	QueueList.enqueue(nextEmployee);
	    	//System.out.println(QueueList.push(nextEmployee));
	    	System.out.println(nextEmployee);
	}
}
